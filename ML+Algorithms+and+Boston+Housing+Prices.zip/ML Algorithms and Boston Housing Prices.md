

```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib
from matplotlib import gridspec
from keras.datasets import boston_housing
from sklearn import preprocessing as p
from sklearn import model_selection as mdl
from keras.models import Sequential
from keras.layers import Dense
```

    Using TensorFlow backend.
    


```python
# Visualization settings
%matplotlib inline
matplotlib.rcParams['figure.figsize'] = (16, 10)
matplotlib.rcParams['ytick.major.pad']='1'
plt.rcParams['axes.labelweight'] = 'bold'
plt.rcParams["axes.labelsize"] = 15

# Print Settings
pd.set_option('display.width', 2000)
pd.set_option('precision', 3)
np.set_printoptions(precision=3, suppress=True)
```


```python

```

## The Dataset
Boston Housing prices, columns are as follows:

    CRIM - per capita crime rate by town
    ZN -proportion of residential land zoned for lots over 25,000 sq.ft.
    INDUS - proportion of non-retail business acres per town.
    CHAS - Charles River dummy variable (1 if tract bounds river; 0 otherwise)
    NOX - nitric oxides concentration (parts per 10 million)
    RM - average number of rooms per dwelling
    AGE - proportion of owner-occupied units built prior to 1940
    DIS - weighted distances to five Boston employment centres
    RAD - index of accessibility to radial highways
    TAX - full-value property-tax rate per 10,000
    PTRATIO - pupil-teacher ratio by town
    B - 1000(Bk - 0.63)^2 where Bk is the proportion of blacks by town
    LSTAT - Percent lower status of the population
    MEDV - Median value of owner-occupied homes in 1000's


```python
(x_train, y_train), (x_test, y_test) = boston_housing.load_data()
```


```python
x_headers = ["CRIM", "ZN","INDUS", "CHAS", "NOX", "RM", "AGE", "DIS", "RAD", "TAX", "PTRATIO", "B", "LSTAT"]
y_headers = ["MEDV"]
```


```python
trainDF = pd.DataFrame(x_train, columns=x_headers)
trainDF['MEDV'] = y_train
trainDF.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CRIM</th>
      <th>ZN</th>
      <th>INDUS</th>
      <th>CHAS</th>
      <th>NOX</th>
      <th>RM</th>
      <th>AGE</th>
      <th>DIS</th>
      <th>RAD</th>
      <th>TAX</th>
      <th>PTRATIO</th>
      <th>B</th>
      <th>LSTAT</th>
      <th>MEDV</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.232</td>
      <td>0.0</td>
      <td>8.14</td>
      <td>0.0</td>
      <td>0.538</td>
      <td>6.142</td>
      <td>91.7</td>
      <td>3.977</td>
      <td>4.0</td>
      <td>307.0</td>
      <td>21.0</td>
      <td>396.90</td>
      <td>18.72</td>
      <td>15.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.022</td>
      <td>82.5</td>
      <td>2.03</td>
      <td>0.0</td>
      <td>0.415</td>
      <td>7.610</td>
      <td>15.7</td>
      <td>6.270</td>
      <td>2.0</td>
      <td>348.0</td>
      <td>14.7</td>
      <td>395.38</td>
      <td>3.11</td>
      <td>42.3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.898</td>
      <td>0.0</td>
      <td>18.10</td>
      <td>0.0</td>
      <td>0.631</td>
      <td>4.970</td>
      <td>100.0</td>
      <td>1.333</td>
      <td>24.0</td>
      <td>666.0</td>
      <td>20.2</td>
      <td>375.52</td>
      <td>3.26</td>
      <td>50.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.040</td>
      <td>0.0</td>
      <td>5.19</td>
      <td>0.0</td>
      <td>0.515</td>
      <td>6.037</td>
      <td>34.5</td>
      <td>5.985</td>
      <td>5.0</td>
      <td>224.0</td>
      <td>20.2</td>
      <td>396.90</td>
      <td>8.01</td>
      <td>21.1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.693</td>
      <td>0.0</td>
      <td>18.10</td>
      <td>0.0</td>
      <td>0.713</td>
      <td>6.376</td>
      <td>88.4</td>
      <td>2.567</td>
      <td>24.0</td>
      <td>666.0</td>
      <td>20.2</td>
      <td>391.43</td>
      <td>14.65</td>
      <td>17.7</td>
    </tr>
  </tbody>
</table>
</div>




```python
print('Number of zero values per column:\n')
_ = [print(h, end='\t') for h in x_headers]
print()
for h in x_headers:
    print((trainDF[h] == 0).sum(), end='\t')
```

    Number of zero values per column:
    
    CRIM	ZN	INDUS	CHAS	NOX	RM	AGE	DIS	RAD	TAX	PTRATIO	B	LSTAT	
    0	300	0	379	0	0	0	0	0	0	0	0	0	

## Observations
 - Whether a house borders the charles river is a boolean value, and most are set to 0.
 - The proportion of residential land zoned for lots over 25,000sq-ft is usually none of it.


```python
fig, axes= plt.subplots(4, 3)
_ = pd.DataFrame(x_train, columns=x_headers).drop('CHAS',1).plot(kind='box',
                                                                 subplots=True, 
                                                                 ax=axes, 
                                                                 showfliers=False, 
                                                                 vert=False,
                                                                 colormap='jet')

_ = fig.suptitle("Spread of Features",fontsize=20)
```


![png](output_9_0.png)



```python
fig, axes= plt.subplots(4, 3)
_ = pd.DataFrame(p.scale(x_train), columns=x_headers).drop('CHAS',1).plot(kind='hist',
                                                                          bins=20,
                                                                          subplots=True, 
                                                                          ax=axes)

_ = fig.suptitle("Distribution of Scaled Features",fontsize=20)

for ax in axes.flat: ax.set_ylabel('')
```


![png](output_10_0.png)



```python
fig, axes= plt.subplots(4, 3)
_ = fig.suptitle('Univariate Analysis; Feature vs Housing Price', fontsize=20)

df = pd.DataFrame(x_train, columns=x_headers).drop('CHAS',1)
headers = df.columns
i = 0

for ax in axes.flat:
    ax.set_title(headers[i], fontweight='bold', fontsize=12)
    ax.scatter(df.iloc[:,i], y_train, s=15, marker='o', edgecolor='grey', linewidth='0.5')
    i += 1
    
plt.subplots_adjust(top=0.92, hspace=0.4)
```


![png](output_11_0.png)


## Observations
- The only feature with a nicely distributed range of values is average number of rooms. The rest seem skewed
- Property Tax rate looks nearly categorical
- accessibility to highways looks pretty categorical
- Room count is correlated to housing price
- Percent lower status of the population is inversely correlated to housing price

## Preprocessing Techniques


### Why Scale?
Most predictive models work best under the assumption that the data is centered about zero, and that all features have an equal magnitude of variance. This equal variance allows the cost function of the model to weight all features equally. If some features are more important than others, they can be scaled differently so that the features variability contributes more to the cost function. Because of this, it's a good idea to translate the dataset so it is centered around zero and scale each feature to have a unit standard deviation. 

It's worth noting that some models, like Decision Tree algorithms are robust to different scales.


### Are any two features highly correlated?


```python
scaled_trainDF = pd.DataFrame(p.scale(trainDF), columns=(x_headers + y_headers))
_ = sns.pairplot(
    data = scaled_trainDF,
    vars=scaled_trainDF.columns,
    hue='MEDV')
```


![png](output_16_0.png)





```python
from dataviz import graph_animator
from matplotlib import rc
from IPython.display import HTML

rc('animation', html='html5')
viz = graph_animator()
```


![png](output_18_0.png)



```python
num_features = x_train.shape[1]

# Construct simple model
def base_model():
    model = Sequential()
    
    model.add(Dense(units=64, 
                    input_dim=num_features,
                    kernel_initializer='normal',
                    activation='relu',
                    use_bias=True))
    model.add(Dense(units=64, 
                    kernel_initializer='normal',
                    activation='relu',
                    use_bias=True))
    model.add(Dense(units=1, 
                    kernel_initializer='normal',
                    activation='linear',
                    use_bias=True))

    model.compile(loss='mean_squared_error', 
                  optimizer='sgd', 
                  metrics=['mae'])

    return model

    
```

## Base Model Notes

If the dataset is small, then there won't be enough samples to be statistically representative of the data at hand. Few data points means the model will be very prone to overfitting, and an overly complex model with a large architecture will optimize very well to the training data but will be too finely tuned to be able to generalize to new examples. For this reason, the model was built as a two layer neural network. Relu activations were included for predicting with non-linearities.

The loss function / optimization function on this model is the Mean Squared Error, which calculates the distance between the predicted value and the ground truth value, squares the difference then sums this value across all examples. Squaring the difference will exponentially penalize inaccurate estimates, creating a steeper gradient descent in initial training. 

The model will be measured by the mean absolute error. This is just the absolute difference between the predicted value and the actual value. This will describe in how many dollars how off was the estimate. 

To test: if different shuffling of data before splitting into test and train yield a different model performance, then there is not enough data and k-folding would be a good approach.


```python
class plot_handler():
    """
    ' Plot handler to help me control the shape of my subplots better.
    """
    def __init__(self, plot_rows, plot_cols):
        self.rows = plot_rows
        self.cols = plot_cols
        self.fig = plt.figure(facecolor='white', figsize=(16,16))
        self.grid = gridspec.GridSpec(self.rows, self.cols)
        
        self.grid.update(left=0.1, 
                         right=0.9, 
                         wspace=0.2,
                         hspace=.15,
                         top=0.9, 
                         bottom=0.1)

        self.ax = {}
        self.xlimit = None
        self.ylimit = None
        
    def __call__(self):
        plt.show
        
    def add_plot(self, top, bottom, left, right, name, title):
        self.ax[name] = self.fig.add_subplot(self.grid[top:bottom, left:right])
        self.ax[name].set_title(title,fontweight="bold", size=14)
        
        # self.ax[name].set_xticks([])
        # self.ax[name].set_yticks([])
    def plot_exists(self, name):
        if name in self.ax:
            return True
        else:
            return False
        
    def plot(self, data, plot_name, ylim=None, c='b', alpha=1.0):
        self.ax[plot_name].plot(data,  '-', c=c, alpha=alpha)
        
        if not ylim:
            self.ax[plot_name].set_ylim([0,ylim])
        
```

### Validating Model using K-folds
K-fold validation is the technique of splitting your data during training and averaging the results of a model trained on the seperate sets. The process goes like this: split your data into k segments. Create k batches of data, where for each batch, the training set has a unique k-1 segments and the validation set is the remaining 1 segment. Train a new model on each of these batches (or folds), averaging the results.


```python
import matplotlib.patches as mpatches


# join the x and y together for shuffling
y_train = y_train.reshape((y_train.shape[0],1))
data = np.hstack([x_train, y_train])

# Make random generation repeatable
seed = 7
np.random.seed(seed)

# small dataset, shuffling and folding the data
shuff_count, i = 3, 0
split_count = 4
epoch_count = 80
b = 0

# Fit a scaling function to the train data
scale = p.StandardScaler().fit(x_train)

subplot = ['Mean Absolute Error', 'Loss'] * 2
metrics = ['mean_absolute_error', 'loss', 'val_mean_absolute_error', 'val_loss']
legends = ['Train', 'Train', 'Validation', 'Validation']

history_set = {metric: np.zeros(shape=(epoch_count, shuff_count * split_count)) for metric in metrics}

plotter = plot_handler(2, 1)
plotter.add_plot(top=0,bottom=1,left=0,right=1, 
                 name='Loss', 
                 title='Average Loss over folded and shuffled data')
plotter.add_plot(top=1,bottom=2, left=0, right=1, 
                 name='Mean Absolute Error',
                 title='House Price estimate vs Actual (in $1000s)')

best_model = base_model()

while i < shuff_count:
    i += 1
    data_folds = mdl.KFold(n_splits=split_count, 
                           shuffle=True, 
                           random_state=seed).split(data)
    
    for dfold in data_folds:
        train, valid = dfold
        
        # Seperate each k fold of train data into a train and validation set
        xt = scale.transform(data[train,:-1])
        yt = data[train,-1:]

        # Transform validation set based on scaling on training set
        xv = scale.transform(data[valid,:-1])
        yv = data[valid,-1:]

        model = base_model()
        history = model.fit(x=xt, 
                            y=yt, 
                            validation_data=(xv, yv),
                            epochs=epoch_count, 
                            verbose=0)
        
        for m in metrics:
            history_set[m][:, b] = history.history[m]

        for metric, plot in zip(metrics, subplot):
            color = 'blue' if  metric[:3] == 'val' else 'green'
            plotter.ax[plot].plot(history.history[metric], 
                                  c=color, 
                                  linewidth=2,
                                  alpha=0.2)
        
        # Evaluate each model, keep the best one
        curr_evaluation = model.evaluate(scale.transform(x_test), y_test, verbose=0)
        best_evaluation = best_model.evaluate(scale.transform(x_test), y_test, verbose=0)
        
        if curr_evaluation[1] < best_evaluation[1]:
            best_model = model
            
        b += 1

# Plot average of all folds
for metric, plot in zip(metrics, subplot):
    color = 'blue' if metric[:3] == 'val' else 'green'
    plotter.ax[plot].plot(np.mean(history_set[metric], axis=1),
                          c=color,
                          linewidth=3,
                          alpha=1.0)
    
# Add Legend
train = mpatches.Patch(color='green', label='Train')
valid = mpatches.Patch(color='blue', label='Validation')

for plot in subplot[:2]:
    plotter.ax[plot].legend(handles=[train, valid])

plotter.ax['Loss'].set_ylim([0,100])
plotter.ax['Mean Absolute Error'].set_ylim([0,10])

plotter()
```


![png](output_23_0.png)


### Notes:

The faded lines show each training session on a unique instantiation of a model. The model's absolute mean error is recorded at the end of each epoch, and the change in loss and mean absolute error is plotted over each epoch. A new model is created and trained on a new partition of shuffled data and is subsequently plotted.

All these training sessions are then averaged together to get a representation of the training and validation loss and mean absolute error.



```python
print('Base Model mean absolute error on test results: $', end='')
mse = np.mean(np.absolute((best_model.predict(scale.transform(x_test)) - y_test[:, None])), axis=0)
print(round(mse[0] * 1000,2))
```

    Base Model mean absolute error on test results: $2323.78
    


```python
from keras import backend as K

# Some memory clean-up
K.clear_session()
```


```python

```


```python

```


```python

```


```python

```


```python

```
